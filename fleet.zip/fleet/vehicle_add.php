<?php

$data = file_get_contents('php://input');

$decoded_data = json_decode($data, true);

$vname = $decoded_data['v_name'];
$vtype = $decoded_data['v_type'];
$vcompany = $decoded_data['v_comp'];

$vlicense = $decoded_data['v_license'];
$VinNumber = $decoded_data['v_vin'];
$EngineNumber = $decoded_data['v_engine'];
$Istart = $decoded_data['v_insurancestart'];

$Estart = $decoded_data['v_insuranceend'];
$aid = $decoded_data['a_id'];

$connection = mysqli_connect('localhost' , 'root' , '');

mysqli_select_db($connection , 'fleet_manager');

$result = mysqli_query($connection , "select EngineNumber from vehicle_table where EngineNumber = '$EngineNumber'");

$rows_found = mysqli_num_rows($result);

if($rows_found == 0)
{

mysqli_query($connection , "insert into vehicle_table (Aid , VehicleType,VehicleCompany,VehicleName,LicensePlate,EngineNumber,VinNumber,InsuranceStartDate
,InsuranceEndDate) values ('$aid','$vtype','$vcompany','$vname','$vlicense','$EngineNumber','$VinNumber','$Istart','$Estart')");
    $response['key'] = "1";
	
	echo json_encode($response);
}

else {
	
	$response['key'] = "0";
	
	echo json_encode($response);
	
	
}



?>