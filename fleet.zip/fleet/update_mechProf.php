<?php

$data = file_get_contents('php://input');

$decoded_data = json_decode($data, true);
 
$aid = $decoded_data['a_id'];
$name = $decoded_data['A_name'];
$uname = $decoded_data['A_Username'];
$mob = $decoded_data['A_mob'];
$pass = $decoded_data['A_pass'];
$email = $decoded_data['A_email'];
$ques = $decoded_data['secQues'];
$ans = $decoded_data['secAns'];
$mid = $decoded_data['mid'];


 
$connection = mysqli_connect('localhost' , 'root' , '');

mysqli_select_db($connection , 'fleet_manager');

$result  = mysqli_query($connection ,"update mechanic set Name ='$name',Username='$uname' ,Email='$email',Password='$pass',Mobile ='$mob',
SecurityAnswer='$ans', SecurityQuestion='$ques' where Aid = '$aid' and Mid='$mid'");
$rows=mysqli_affected_rows($connection);
if($rows== -1)
{
	 $response['key'] = "0";
	 //$response['test'] = $rows;
	// $response['mob'] = $mob;
	 echo json_encode($response);
}
else if($rows== 0)
{
	 $response['key'] = "2";
	 echo json_encode($response);
}
else
{
	$response['key'] = "1";
	// $response['test'] = $rows;
	// $response['mob'] = $mob;
	 echo json_encode($response);
}

 
 


?>