<?php

$data = file_get_contents('php://input');

$decoded_data = json_decode($data, true);
$a_id = $decoded_data['a_id'];
$dr_id = $decoded_data['dr_id'];
$dr_date = $decoded_data['dr_date'];
$dr_to = $decoded_data['dr_to'];
$dr_from = $decoded_data['dr_from'];
$dr_material = $decoded_data['dr_material'];
$dr_fuel = $decoded_data['dr_fuel'];
$dr_distance = $decoded_data['dr_distance'];
$dr_odometer = $decoded_data['dr_odometer'];

$connection = mysqli_connect('localhost' , 'root' , '');

mysqli_select_db($connection , 'fleet_manager');

$result = mysqli_query($connection , "select d_id from driver_log where d_id = '$dr_id'");

$rows_found = mysqli_num_rows($result);

if($rows_found == 0)
{

mysqli_query($connection , "insert into driver_log (d_id,a_id,FromLocation,ToLocation,Material,Distance,FuelCard,Odometer,Date) 
values ('$dr_id','$a_id','$dr_from','$dr_to','$dr_material','$dr_distance','$dr_fuel','$dr_odometer','$dr_date')");
    $response['key'] = "1";
	$response['resz']=mysqli_affected_rows($connection);
	echo json_encode($response);
}

else {
	
	$response['key'] = "0";
	
	echo json_encode($response);
	
	
}



?>