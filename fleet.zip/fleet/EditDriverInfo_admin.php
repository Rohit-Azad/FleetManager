<?php

$data = file_get_contents('php://input');

$decoded_data = json_decode($data, true);
 
$aid = $decoded_data['a_id'];
$editDriver_name = $decoded_data['editDriver_name'];
$editDriver_vehicle = $decoded_data['editDriver_vehicle'];
$editDriver_mobile = $decoded_data['editDriver_mobile'];
$dr_id = $decoded_data['dr_id'];
$editPassword = $decoded_data['editPassword'];
$editUsername = $decoded_data['editUsername'];
$dLicenseNumber = $decoded_data['editDriver_dLicenseNumber'];

 
$connection = mysqli_connect('localhost' , 'root' ,'');

mysqli_select_db($connection , 'fleet_manager');

$result  = mysqli_query($connection ,"update driver set Name ='$editDriver_name',
														vehicle ='$editDriver_vehicle', 
														DLicense ='$dLicenseNumber',
														Username='$editUsername',
														Password='$editPassword',
														Mobile='$editDriver_mobile'
														where Aid = '$aid' and Did='$dr_id'");
 $rows=mysqli_affected_rows($connection);
if($rows== -1)
{
	 $response['key'] = "0";
	 $response['error'] = mysqli_error($connection);
	 //$response['test'] = $rows;
	// $response['mob'] = $mob;
	 echo json_encode($response);
	 
}
else if($rows== 0)
{
	 $response['key'] = "2";
	 echo json_encode($response);
}
else
{
	$response['key'] = "1";
	// $response['test'] = $rows;
	// $response['mob'] = $mob;
	 echo json_encode($response);
}


 
 echo json_encode($response)


?>