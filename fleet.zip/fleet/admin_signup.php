<?php

$data = file_get_contents('php://input');

$decoded_data = json_decode($data, true);

$name = $decoded_data['name'];
$username = $decoded_data['username'];
$email = $decoded_data['email'];

$mobile = $decoded_data['mobile'];
$password = $decoded_data['pass'];

$connection = mysqli_connect('localhost' , 'root' , '');

mysqli_select_db($connection , 'fleet_manager');

$result = mysqli_query($connection , "select Username from admin_signup where Username = '$username'");

$rows_found = mysqli_num_rows($result);

if($rows_found == 0)
{

mysqli_query($connection , "insert into admin_signup (Name , Username,Email,Password,Mobile ) values ('$name','$username' , '$email' , '$password','$mobile')");

$response['key'] = "1";
	
	echo json_encode($response);
}

else {
	
	$response['key'] = "0";
	
	echo json_encode($response);
	
	
}



?>