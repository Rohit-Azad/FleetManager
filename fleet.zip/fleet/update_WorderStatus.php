<?php

$data = file_get_contents('php://input');

$decoded_data = json_decode($data, true);
 
$aid = $decoded_data['a_id'];
$mid = $decoded_data['m_mid'];
$status = $decoded_data['m_status'];
$wrkID = $decoded_data['M_wid'];
 

 
$connection = mysqli_connect('localhost' , 'root' ,'');

mysqli_select_db($connection , 'fleet_manager');

$result  = mysqli_query($connection ,"update workorder set Status ='$status'  where Aid = '$aid' and Wid='$wrkID'");
 $rows=mysqli_affected_rows($connection);
if($rows== -1)
{
	 $response['key'] = "0";
	 //$response['test'] = $rows;
	// $response['mob'] = $mob;
	 echo json_encode($response);
}
else if($rows== 0)
{
	 $response['key'] = "2";
	 echo json_encode($response);
}
else
{
	$response['key'] = "1";
	// $response['test'] = $rows;
	// $response['mob'] = $mob;
	 echo json_encode($response);
}


 
 echo json_encode($response)


?>