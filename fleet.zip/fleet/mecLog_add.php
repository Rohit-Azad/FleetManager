<?php

$data = file_get_contents('php://input');

$decoded_data = json_decode($data, true);
$aid = $decoded_data['a_id'];
$mid = $decoded_data['m_id'];
$date = $decoded_data['m_date'];
$license = $decoded_data['m_license'];

$mwid = $decoded_data['m_workOrderID'];
$workhour = $decoded_data['m_workHour'];
 


$connection = mysqli_connect('localhost' , 'root' , '');

mysqli_select_db($connection , 'fleet_manager');

$result = mysqli_query($connection , "select Wid from mechanic_log where Wid = '$mwid'");

$rows_found = mysqli_num_rows($result);

if($rows_found == 0)
{

mysqli_query($connection , "insert into mechanic_log (Mid,Aid,Wid,VehiclePlate,NumofHours,Date) 
values ('$mid','$aid','$mwid','$license','$workhour','$date')");
    $response['key'] = "1";
	
	echo json_encode($response);
}

else {
	
	$response['key'] = "0";
	
	echo json_encode($response);
	
	
}



?>