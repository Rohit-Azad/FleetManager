 
<?php
$data = file_get_contents('php://input');
// decoding the json object
$decoded_data = json_decode($data , true);
$id = $decoded_data['id_key']; // give keys which are given in app while creating json object
 $mobile = $decoded_data['mobile'];
 //$role = $decoded_data['role'];
 $id_field = $decoded_data['id_field'];
 $tName = $decoded_data['tName'];
 $pass = $decoded_data['pass'];


$connection = mysqli_connect('localhost' , 'root' , '');
// selecting database user 
mysqli_select_db($connection , 'fleet_manager');



 //$result  = mysqli_query($connection , "select * from $tName where $id_field = '$id' and Mobile='$mobile' ");
 $result  = mysqli_query($connection ,"update $tName set Password ='$pass'
															where Mobile ='$mobile' and $id_field = '$id'");
																											
 if(mysqli_affected_rows($connection)==0)
 {
	 $response['key'] = "0";
	//  $response['error'] = mysqli_error($connectionz);
	  echo json_encode($response);
 }
 else
 {

	//$r = mysqli_fetch_array($result);
	$response['key'] = "1";
	
	 echo json_encode($response);
 }
 
 

?>