<?php

$data = file_get_contents('php://input');

$decoded_data = json_decode($data, true);
 
$aid = $decoded_data['a_id'];
$name = $decoded_data['A_name'];
$dLicense = $decoded_data['A_dLicense'];
$mob = $decoded_data['A_mob'];
$pass = $decoded_data['A_pass'];
$vehicle = $decoded_data['A_vehicle'];
$d_id = $decoded_data['did'];

$connection = mysqli_connect('localhost' , 'root' , '');

mysqli_select_db($connection , 'fleet_manager');

$result  = mysqli_query($connection ,"update driver set Name ='$name', DLicense='$dLicense',vehicle='$vehicle',Password='$pass',Mobile ='$mob' where Aid = '$aid' and Did='$d_id'");
$rows=mysqli_affected_rows($connection);
if($rows== -1)
{
	 $response['key'] = "0";
	 //$response['test'] = $rows;
	// $response['mob'] = $mob;
	 echo json_encode($response);
}
else if($rows== 0)
{
	 $response['key'] = "2";
	 echo json_encode($response);
}
else
{
	$response['key'] = "1";
	// $response['test'] = $rows;
	// $response['mob'] = $mob;
	 echo json_encode($response);
}

 
 


?>