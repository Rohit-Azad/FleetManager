<?php

$connection = mysqli_connect('localhost','root','');
mysqli_select_db($connection,'fleet_manager');
$data = file_get_contents('php://input');
$decoded_data = json_decode($data,true);
$ad_id= $decoded_data['admin_id_here'];
$sql=mysqli_query($connection , "select * from workorder  where Aid = '$ad_id' and Status='Open' or Status='in progress'");

  
  while($row=mysqli_fetch_assoc($sql))
  $output[]=$row;


$response['result'] = $output;
 echo (json_encode($response));
  mysqli_close($connection);
?>