<?php

$data = file_get_contents('php://input');

$decoded_data = json_decode($data, true);

$vname = $decoded_data['v_name'];
$vlicense = $decoded_data['v_license'];
$vtype = $decoded_data['v_vtype'];
$vcompany = $decoded_data['v_comp'];
$VinNumber = $decoded_data['v_vin'];
$Issue = $decoded_data['issues'];
$date = $decoded_data['datte'];
$state=$decoded_data['status'];
$aid = $decoded_data['a_id'];
$did = $decoded_data['d_did'];
$connection = mysqli_connect('localhost' , 'root' , '');

mysqli_select_db($connection , 'fleet_manager');

$result = mysqli_query($connection , "select Issue from workorder where Issue = '$Issue'");

$rows_found = mysqli_num_rows($result);

if($rows_found == 0)
{

mysqli_query($connection , "insert into workorder (Aid,Did,VinNumber,VCompany,VehicleName,LicensePlate,VehicleType,Date,Issue,Status) 
values ('$aid','$did','$VinNumber','$vcompany','$vname','$vlicense','$vtype','$date','$Issue','$state')");
    $response['key'] = "1";
	
	echo json_encode($response);
}

else {
	
	$response['key'] = "0";
	
	echo json_encode($response);
	
	
}



?>