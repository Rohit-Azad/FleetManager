<?php

$data = file_get_contents('php://input');

$decoded_data = json_decode($data, true);

$dname = $decoded_data['d_name'];
$dusername = $decoded_data['d_username'];
$dlicense = $decoded_data['d_license'];

$vehicle = $decoded_data['d_vehicle'];
$dpassword = $decoded_data['d_password'];
 $mobile = $decoded_data['d_mobile'];
$aid = $decoded_data['a_id'];

$connection = mysqli_connect('localhost' , 'root' , '');

mysqli_select_db($connection , 'fleet_manager');

$result = mysqli_query($connection , "select DLicense from driver where DLicense = '$dlicense'");

$rows_found = mysqli_num_rows($result);

if($rows_found == 0)
{

mysqli_query($connection , "insert into driver (Aid,Name,Username,vehicle,DLicense,Mobile,Password) values ('$aid','$dname','$dusername','$vehicle','$dlicense','$mobile','$dpassword')");
    $response['key'] = "1";
	
	echo json_encode($response);
}

else {
	
	$response['key'] = "0";
	
	echo json_encode($response);
	
	
}



?>