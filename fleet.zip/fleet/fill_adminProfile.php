 
<?php
$data = file_get_contents('php://input');
// decoding the json object
$decoded_data = json_decode($data , true);
$id = $decoded_data['id_key']; // give keys which are given in app while creating json object
 


$connection = mysqli_connect('localhost' , 'root' , '');
// selecting database user 
mysqli_select_db($connection , 'fleet_manager');



 $result  = mysqli_query($connection , "select * from admin_signup where id = '$id' ");
 
 while($r = mysqli_fetch_assoc($result))
 $row[] = $r;
$response['result']= $row;
 
 echo json_encode($response);


?>