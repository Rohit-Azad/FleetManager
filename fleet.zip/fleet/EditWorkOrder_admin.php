<?php

$data = file_get_contents('php://input');

$decoded_data = json_decode($data, true);
 
$aid = $decoded_data['a_id'];
$A_issue = $decoded_data['A_issue'];
$A_date = $decoded_data['A_date'];
$A_status = $decoded_data['A_status'];
$w_id = $decoded_data['w_id'];
 

 
$connection = mysqli_connect('localhost' , 'root' ,'');

mysqli_select_db($connection , 'fleet_manager');

$result  = mysqli_query($connection ,"update workorder set Status ='$A_status', Date ='$A_date', Issue ='$A_issue'  where Aid = '$aid' and Wid='$w_id'");
 $rows=mysqli_affected_rows($connection);
if($rows== -1)
{
	 $response['key'] = "0";
	 $response['error'] = mysqli_error($connection);
	 //$response['test'] = $rows;
	// $response['mob'] = $mob;
	 echo json_encode($response);
	 
}
else if($rows== 0)
{
	 $response['key'] = "2";
	 echo json_encode($response);
}
else
{
	$response['key'] = "1";
	// $response['test'] = $rows;
	// $response['mob'] = $mob;
	 echo json_encode($response);
}


 
 echo json_encode($response)


?>