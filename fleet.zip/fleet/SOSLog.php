<?php

$data = file_get_contents('php://input');

$decoded_data = json_decode($data, true);

$timestamp = $decoded_data['timestamp'];
$lng = $decoded_data['lng'];
$lat = $decoded_data['lat'];
$address = $decoded_data['address'];
$aid = $decoded_data['a_id'];
$did = $decoded_data['d_id'];

$connection = mysqli_connect('localhost' , 'root' , '');

mysqli_select_db($connection , 'fleet_manager');

$result = mysqli_query($connection , "select TStamp from sos_logs where TStamp = '$timestamp'");

$rows_found = mysqli_num_rows($result);

if($rows_found == 0)
{

mysqli_query($connection , "insert into sos_logs (Aid,Did,Latitude,Longitude,Address,TStamp) values ('$aid','$did','$lat','$lng','$address','$timestamp')");
    $response['key'] = "1";
	
	echo json_encode($response);
}

else {
	
	$response['key'] = "0";
	
	echo json_encode($response);
	
	
}



?>