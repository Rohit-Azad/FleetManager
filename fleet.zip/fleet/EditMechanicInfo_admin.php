<?php

$data = file_get_contents('php://input');

$decoded_data = json_decode($data, true);
 
$aid = $decoded_data['a_id'];
$m_id = $decoded_data['m_id'];
$editMechanc_name = $decoded_data['editMechanc_name'];
$editMechanc_secques = $decoded_data['editMechanc_secques'];
$editMechanc_secans = $decoded_data['editMechanc_secans'];
$editMechanc_mobile = $decoded_data['editMechanc_mobile'];
$editMechanc_pass = $decoded_data['editMechanc_pass'];
$editMechanc_username = $decoded_data['editMechanc_username'];
$editMechanc_email = $decoded_data['editMechanc_email'];

 
$connection = mysqli_connect('localhost' , 'root' ,'');

mysqli_select_db($connection , 'fleet_manager');

$result  = mysqli_query($connection ,"update mechanic set Name ='$editMechanc_name',
														Email ='$editMechanc_email', 
														SecurityQuestion ='$editMechanc_secques',
														Username='$editMechanc_username',
														Password='$editMechanc_pass',
														SecurityAnswer='$editMechanc_secans',
														Mobile='$editMechanc_mobile'
														where Aid = '$aid' and Mid='$m_id'");
 $rows=mysqli_affected_rows($connection);
if($rows== -1)
{
	 $response['key'] = "0";
	 $response['error'] = mysqli_error($connection);
	 //$response['test'] = $rows;
	// $response['mob'] = $mob;
	 echo json_encode($response);
	 
}
else if($rows== 0)
{
	 $response['key'] = "2";
	 echo json_encode($response);
}
else
{
	$response['key'] = "1";
	// $response['test'] = $rows;
	// $response['mob'] = $mob;
	 echo json_encode($response);
}


 
 echo json_encode($response)


?>