<?php

$connection = mysqli_connect('localhost','root','');
mysqli_select_db($connection,'fleet_manager');
$data = file_get_contents('php://input');
$decoded_data = json_decode($data,true);
$ad_id= $decoded_data['admin_id_here'];

$FromDate= $decoded_data['FromDate'];
$toDate= $decoded_data['toDate'];
$tableName= $decoded_data['tableName'];
$id= $decoded_data['id'];


$sql=mysqli_query($connection , "select * from $tableName  where $id = '$ad_id' and Date>='$FromDate' and Date<='$toDate'");

  
  while($row=mysqli_fetch_assoc($sql))
  $output[]=$row;




$response['result'] = $output;
 echo (json_encode($response));
  mysqli_close($connection);
?>