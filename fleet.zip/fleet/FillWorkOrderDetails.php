<?php
// reading data which is sent from app in jsonobject form
$data = file_get_contents('php://input');
// decoding the json object
$decoded_data = json_decode($data , true);
$WorkID = $decoded_data['m_workOrderID']; // give keys which are given in app while creating json object

 
 $aid = $decoded_data['a_id'];
// creating connection with database and saving in variable  




$connection = mysqli_connect('localhost' , 'root' , '');
// selecting database user 
mysqli_select_db($connection , 'fleet_manager');
// query to check whether same email and password exist or not
$result = mysqli_query($connection , "select * from workorder where Wid = '$WorkID' and Aid = '$aid' ");
// fetching number of rows returned in query 
$rows = mysqli_num_rows($result);
// if now row found mean no such data sent by user found in database
if($rows == 0)
	
	{
		// making key value pair with key named 'key' and value "not done"
		$response['key'] = "0";
		// converting key value pair into jsonobject form
		echo json_encode($response);
	}
	
	// if some row found mean data found in database
	else {
		// making key value pair with key named 'key' and value "not done"
		$r = mysqli_fetch_array($result);
		
		
		$response['LicensePlate'] = $r['LicensePlate'];
		$response['Date'] = $r['Date'];
		$response['key'] = "1";
	 
		// converting key value pair into jsonobject form
		echo json_encode($response);
		
		
	}
?>