<?php

$data = file_get_contents('php://input');

$decoded_data = json_decode($data, true);

$Mname = $decoded_data['m_name'];
$Mmobile = $decoded_data['m_mobile'];
$Memail = $decoded_data['m_email'];

$Musername = $decoded_data['m_username'];
$Mpassword = $decoded_data['m_password'];
$Msec = $decoded_data['m_security'];
 $MsecA = $decoded_data['m_securityA'];
$aid = $decoded_data['a_id'];

$connection = mysqli_connect('localhost' , 'root' , '');

mysqli_select_db($connection , 'fleet_manager');

$result = mysqli_query($connection , "select Username from mechanic where Username = '$Musername'");

$rows_found = mysqli_num_rows($result);

if($rows_found == 0)
{

mysqli_query($connection , "insert into mechanic(Aid,Name,Mobile,Email,Username,Password,SecurityQuestion,SecurityAnswer) values ('$aid','$Mname','$Mmobile','$Memail','$Musername','$Mpassword','$Msec','$MsecA')");
    $response['key'] = "1";
	
	$response['test']=mysqli_affected_rows($connection);
	
	echo json_encode($response);
}

else {
	$response['test']=mysqli_affected_rows($connection);
	
	$response['key'] = "0";
	
	echo json_encode($response);
	
	
}


?>