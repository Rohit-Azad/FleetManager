<?php

$data = file_get_contents('php://input');

$decoded_data = json_decode($data, true);

$a_id = $decoded_data['a_id'];
$m_id = $decoded_data['mechanic_id'];
$etVid = $decoded_data['etVid'];
$etCompany = $decoded_data['etCompany'];
$etLPlate = $decoded_data['etLPlate'];
$etInvoice = $decoded_data['etInvoice'];
$etTotal = $decoded_data['etTotal'];
$etPartsOrdered = $decoded_data['etPartsOrdered'];
$etDate = $decoded_data['etDate'];

$connection = mysqli_connect('localhost' , 'root' , '');

mysqli_select_db($connection , 'fleet_manager');

$result = mysqli_query($connection , "select Invoice from orderparts where Invoice = '$etInvoice'");

$rows_found = mysqli_num_rows($result);

if($rows_found == 0)
{

mysqli_query($connection , "insert into orderparts (Mid,Vid,Aid, LicensePlate,PartsOrdered,Company,Invoice,Total,Date) 
			values ('$m_id','$etVid','$a_id','$etLPlate','$etPartsOrdered','$etCompany','$etInvoice','$etTotal','$etDate')");
			
    $response['key'] = "1";
	$response['error']=mysqli_error($connection);
	echo json_encode($response);
}

else {
	
	$response['key'] = "0";
	$response['error']=mysqli_error($connection);
	echo json_encode($response);
	
	
}



?>