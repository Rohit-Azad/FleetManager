<?php

$data = file_get_contents('php://input');

$decoded_data = json_decode($data, true);
 
$aid_value = $decoded_data['aid_value'];
$aid = $decoded_data['aid'];
$vid = $decoded_data['id'];
$vid_value = $decoded_data['id_value'];
$table = $decoded_data['table'];
 

 
$connection = mysqli_connect('localhost' , 'root' ,'');

mysqli_select_db($connection , 'fleet_manager');

$result  = mysqli_query($connection ,"DELETE FROM $table  where $vid='$vid_value' AND $aid='$aid_value'");
 $rows=mysqli_affected_rows($connection);
if($rows== -1)
{
	 $response['key'] = "0";
	  $response['test'] = mysqli_error($connection);
	 //$response['test'] = $rows;
	// $response['mob'] = $mob;
	 echo json_encode($response);
}
else if($rows== 0)
{
	 $response['key'] = "2";
	 $response['test'] = mysqli_error($connection);
	 echo json_encode($response);
}
else
{
	$response['test'] = mysqli_error($connection);
	$response['key'] = "1";
	// $response['test'] = $rows;
	// $response['mob'] = $mob;
	 echo json_encode($response);
}


 
 echo json_encode($response)


?>