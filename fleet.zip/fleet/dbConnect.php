<?php
 $servername = "localhost";
$uname = "root";
$password = "";
$dbname = "fleet_manager";
$con = mysqli_connect($servername, $uname, $password, $dbname) or die('Unable to Connect'); 
 ?>