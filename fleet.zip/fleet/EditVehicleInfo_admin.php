<?php

$data = file_get_contents('php://input');

$decoded_data = json_decode($data, true);
 
$a_id = $decoded_data['a_id'];
$v_id = $decoded_data['v_id'];
$ev_editName = $decoded_data['ev_editName'];
$ev_editLicense = $decoded_data['ev_editLicense'];
$ev_editComp = $decoded_data['ev_editComp'];
$ev_editType = $decoded_data['ev_editType'];
$ev_editVin = $decoded_data['ev_editVin'];
$ev_editEngNum = $decoded_data['ev_editEngNum'];
$ev_editInsEnd = $decoded_data['ev_editInsEnd'];
$ev_editInsStart = $decoded_data['ev_editInsStart'];

 
$connection = mysqli_connect('localhost' , 'root' ,'');

mysqli_select_db($connection , 'fleet_manager');

$result  = mysqli_query($connection ,"update vehicle_table set VehicleName ='$ev_editName',
																VehicleType ='$ev_editType', 
																VehicleCompany ='$ev_editComp',
																LicensePlate='$ev_editLicense',
																EngineNumber='$ev_editEngNum',
																VinNumber='$ev_editVin',
																InsuranceStartDate='$ev_editInsStart',
																InsuranceEndDate='$ev_editInsEnd'
																where Aid = '$a_id' and Vid='$v_id'");

$rows=mysqli_affected_rows($connection);
if($rows== -1)
{
	 $response['key'] = "0";
	 $response['error'] = mysqli_error($connection);
	 //$response['test'] = $rows;
	// $response['mob'] = $mob;
	 echo json_encode($response);
	 
}
else if($rows== 0)
{
	 $response['key'] = "2";
	 echo json_encode($response);
}
else
{
	$response['key'] = "1";
	// $response['test'] = $rows;
	// $response['mob'] = $mob;
	 echo json_encode($response);
}


 
 echo json_encode($response)


?>